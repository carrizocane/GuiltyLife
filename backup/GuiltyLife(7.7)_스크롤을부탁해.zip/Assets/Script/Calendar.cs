﻿using System.Collections;
using UnityEngine;
using System.Globalization;
using System;
using System.Collections.Generic;

public class Calendar : MonoBehaviour
{

    public UILabel date;
    public GameObject calendar;
    public static UILabel detailLabel;

    public static DateTime currentDate;
    public static DateTime tempDate;    // update Calendar에서 쓰는 Date 변수
    

    void Awake()
    {
        currentDate = DateTime.Now;      // 이 인스턴스 생길 때 딱 한번 실행이니까 여기다 씀
        tempDate = currentDate;
    }

    void OnEnable()
    {
        date.text = tempDate.Year.ToString() + "년 " + tempDate.Month.ToString() + "월";
        updateCalendar();
    }

    void updateCalendar()
    {
        int i = 1;
        DateTime extraDate = new DateTime(tempDate.Year,  tempDate.Month, 1);
        GameObject week;
        UILabel dayNum;

        for (int j = 1; j <= 6; j++) {
            week = calendar.transform.Find("week ("+j+")").gameObject;
            for (int k = 1; k <= 7; k++)
            {
                dayNum = (UILabel)week.transform.Find("day ("+k+")").gameObject.transform.Find("Label").GetComponent("UILabel");
                dayNum.text = null;
            }
        }

        week = calendar.transform.Find("week (1)").gameObject;
        while (tempDate.Month == extraDate.Month)
        {
            switch (extraDate.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (1)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Monday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (2)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Tuesday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (3)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Wednesday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (4)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Thursday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (5)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Friday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (6)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Saturday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (7)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        i++;
                        week = calendar.transform.Find("week (" + i + ")").gameObject;
                        break;
                    }
            }
            extraDate = extraDate.AddDays(1);
        }
    }

    public void gotoCalendarList()
    {
        GM.calendar.SetActive(false);
        GM.calendarList.SetActive(true);
    }

    public void gotoMyRoom()
    {
        GM.calendar.SetActive(false);
        GM.myRoom.SetActive(true);
        GM.getInstance().slideButton.SetActive(true);       //myRoom 켤 때는 얘도 켜야해염
    }

    public void preMonthButton()
    {
        tempDate =  tempDate.AddMonths(-1);
        date.text =  tempDate.Year.ToString() + "년 " +  tempDate.Month.ToString() + "월";
        updateCalendar();
    }

    public void nextMonthButton()
    {
        tempDate =  tempDate.AddMonths(1);
        date.text =  tempDate.Year.ToString() + "년 " +  tempDate.Month.ToString() + "월";
        updateCalendar();
    }

    public static void touch(GameObject day)
    {
        UILabel dayNum = (UILabel)day.transform.Find("Label").GetComponent("UILabel");
        List<Schedule> selectScheduleList;
        tempDate = new DateTime(tempDate.Year, tempDate.Month, Convert.ToInt32(dayNum.text));
        //라벨값 받아와서 tempDate 바꿔줌
        if (tempDate.Month >= 10 && tempDate.Day >= 10)
        {
           selectScheduleList = GM.loadSaveManager.getSchedulesWithDate(tempDate.Year + "-" + tempDate.Month + "-" + tempDate.Day);

            for (int i = 0; i < selectScheduleList.Count; i++) {
                detailLabel.text = selectScheduleList[i].getContent()+"\n";
            }

        }
        else if (tempDate.Month >= 10)
        {
            selectScheduleList = GM.loadSaveManager.getSchedulesWithDate(tempDate.Year + "-" + tempDate.Month + "-0" + tempDate.Day);
            for (int i = 0; i < selectScheduleList.Count; i++)
            {
                detailLabel.text = selectScheduleList[i].getContent() + "\n";
            }
        }
        else if (tempDate.Day >= 10)
        {
            selectScheduleList = GM.loadSaveManager.getSchedulesWithDate(tempDate.Year + "-0" + tempDate.Month + "-" + tempDate.Day);
            for (int i = 0; i < selectScheduleList.Count; i++)
            {
                detailLabel.text = selectScheduleList[i].getContent() + "\n";
            }
        }
        else {
            selectScheduleList = GM.loadSaveManager.getSchedulesWithDate(tempDate.Year + "-0" + tempDate.Month + "-0" + tempDate.Day);
            for (int i = 0; i < selectScheduleList.Count; i++)
            {
                detailLabel.text = selectScheduleList[i].getContent() + "\n";
            }
        }
    }

}