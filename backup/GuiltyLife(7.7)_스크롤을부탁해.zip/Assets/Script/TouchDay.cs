﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchDay : MonoBehaviour {
    void OnClick()
    {
        Calendar.touch(this.gameObject);
    }
}
