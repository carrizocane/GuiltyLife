﻿using UnityEngine;
using System.Collections;

public class MyRoom : MonoBehaviour {
    
    // variables
    public UISprite settingButton;
    public UISprite collectionButton;
    public UISprite medalButton;

    // Use this for initialization
    void Start () {
	}

    /* TODO:
     * LeftSlide obj가 inactive 상태이면, 터치드래그 했을 때, GM의 LeftSlideOn() 호출 해야함
     */
    void Update () {
        if (Input.GetKeyDown(KeyCode.Escape) && !GM.leftSlide.activeSelf)
        {
            Application.Quit();
        }
    }

    void OnClick()
    {
        // LeftSlide obj가 active 상태이며, 이 바깥부분 눌렀을 때 => LeftSlide OFF
        if (GM.leftSlide.activeSelf)
        {
            GM.getInstance().LeftSlideOff();
        }
    }

}
