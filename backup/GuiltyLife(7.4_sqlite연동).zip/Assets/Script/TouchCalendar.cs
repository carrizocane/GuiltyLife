﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchCalendar : MonoBehaviour {

    public void gotoAddWork()
    {
        GM.calendarList.SetActive(false);
        //원래 위에 9번줄 false하면 안되는뎅..근데 false해도 안없어지고
        //false를 안하면 쟤의 depth가 낮은데도 불구하고 위로 올라옴..;;
        GM.addWork.SetActive(true);
    }

    public void gotoCalendar() {
        GM.calendarList.SetActive(false);
        GM.calendar.SetActive(true);
    }
}
