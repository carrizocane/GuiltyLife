﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ex : MonoBehaviour {
    
    public void me() {
        GM.myRoom.SetActive(false);
        GM.goodEndingObj.SetActive(true);

    }

}
