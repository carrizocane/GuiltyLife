﻿using UnityEngine;
using System.Collections;

public class GoodEnding : MonoBehaviour
{

    public GameObject goodEnding;
    UISprite black;
    float m_fDuration = 3f;

    void Start()
    {
        black = goodEnding.transform.Find("Black").GetComponent<UISprite>();
    }

    public void fadeIn()
    {
        Debug.Log("페이드인 실행");

        goodEnding.transform.Find("Labels").gameObject.SetActive(false);
        StartCoroutine(FadeIn());
        goodEnding.transform.Find("Black").gameObject.SetActive(false);

        Destroy(black.GetComponent<BoxCollider2D>());
        Destroy(black.GetComponent<UIButton>());
        //  Destroy(black.GetComponent<TweenAlpha>());
        //이쪽오류 뭔지 모르겠는걸..?ㅜ
        //나중에 정 안되면 다른 2dCollider로 덮어씌우기..ㅜ
        // Destroy(black);

    }

    IEnumerator FadeOut()
    {
        //FadeOut 
        TweenAlpha.Begin(black.gameObject, m_fDuration, 1f);
        yield return new WaitForSeconds(m_fDuration);

    }
    IEnumerator FadeIn()
    {
        //FadeIn 
        TweenAlpha.Begin(black.gameObject, m_fDuration, 0f);
        yield return new WaitForSeconds(m_fDuration);

    }

    public void openLetter()
    {
        goodEnding.transform.Find("Letter").gameObject.SetActive(true);
        goodEnding.transform.Find("PostBox").gameObject.SetActive(true);
        goodEnding.transform.Find("PostBox&Letter").gameObject.SetActive(false);
    }

    public void closeLetter()
    {
        goodEnding.transform.Find("Letter").gameObject.SetActive(false);
        goodEnding.transform.Find("Gift").gameObject.SetActive(true);
        tweenGift();
    }

    void tweenGift()
    {
        TweenScale tw = goodEnding.transform.Find("Gift").gameObject.AddComponent<TweenScale>();
        tw.from.x = 0.9f;
        tw.to.x = 1.1f;
        tw.from.y = 0.9f;
        tw.to.y = 1.1f;
        tw.duration = 1f;
        tw.style = UITweener.Style.Loop;
        tw.PlayForward();
    }

    public void touchGift()
    {
        goodEnding.transform.Find("Gift").gameObject.SetActive(false);
        goodEnding.transform.Find("White").gameObject.SetActive(true);
        //얘는 트윈 왜 지멋대로 켜짐..?ㅡ
        //트윈끝나면 이 밑의 아이 틀고싶음
        goodEnding.transform.Find("GetItem").gameObject.SetActive(true);
        
    }

    public void touchGetItem() {

        goodEnding.transform.Find("GetItem").gameObject.SetActive(false);
        goodEnding.transform.Find("White").gameObject.SetActive(false); 


    }

}