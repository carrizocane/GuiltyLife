﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddWork: MonoBehaviour
{
    public GameObject inputContent;
    public string inputStr;

    public void getContentInput() {//내용입력받음
        //여기서 내용글자갯수나 그런거 제한해줘야할듯
        UIInput input = inputContent.GetComponent<UIInput>();
        inputStr = input.label.text;
    }

    public void addWork()
    {
        string tempDateString; //날 받아옴 string으로
        if (Calendar.tempDate.Month >= 10 && Calendar.tempDate.Day >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-" + Calendar.tempDate.Month + "-" + Calendar.tempDate.Day;
        }
        else if (Calendar.tempDate.Month >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-" + Calendar.tempDate.Month + "-0" + Calendar.tempDate.Day;
        }
        else if (Calendar.tempDate.Day >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-0" + Calendar.tempDate.Month + "-" + Calendar.tempDate.Day;
        }
        else
        {
            tempDateString = Calendar.tempDate.Year + "-0" + Calendar.tempDate.Month + "-0" + Calendar.tempDate.Day;
        }
        
        Schedule newWork = new Schedule(inputStr,"USER",tempDateString,false,false,1);
        GM.loadSaveManager.insertSchedule(newWork);

        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }
    public void cancel()
    {
        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }

}
