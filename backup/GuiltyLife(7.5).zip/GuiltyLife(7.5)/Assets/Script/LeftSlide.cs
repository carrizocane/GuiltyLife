﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LeftSlide : MonoBehaviour
{

    public UIGrid basicGrid;
    public UIGrid userGrid;
    public GameObject basicScroll;
    public GameObject userScroll;
    public GameObject date;

    // Use this for initialization
    void OnEnable() {

        UILabel year = (UILabel)date.transform.Find("year").GetComponent("UILabel");
        UILabel day = (UILabel)date.transform.Find("day").GetComponent("UILabel");
        year.text = GM.currentDate.Year.ToString() + "년";
        day.text = GM.currentDate.Month.ToString() + "월 " + GM.currentDate.Day.ToString() + "일";

    }

    void Start()
    {
        GameObject prefab = Resources.Load("Prefabs/listItem") as GameObject;
        // Resources/Prefabs/listItem.prefab 로드
        GameObject listItem;
        UILabel label;

        List<Schedule> scheduleList = GM.loadSaveManager.ScheduleDbParsing();
        //데이터 받아옴

        for (int i = 0; i < scheduleList.Count; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "basicItemList"; // name을 변경

            label = (UILabel)listItem.transform.Find("Label").GetComponent("UILabel"); //라벨 찾아서
            label.text = scheduleList[i].getContent(); //내용넣기

            if (scheduleList[i].getDone()) //만약 이미 한 상태면
            {
                listItem.transform.Find("checkIcon").gameObject.SetActive(true); //체크하기
            }

            listItem.transform.SetParent(basicGrid.transform);
            listItem.transform.localScale = new Vector3(1, 1, 1);
        }
        basicGrid.Reposition();
        for (int i = 0; i < 2; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "userItemList"; // name을 변경

            listItem.transform.SetParent(userGrid.transform);
            listItem.transform.localScale = new Vector3(1, 1, 1);
        }
        userGrid.Reposition();

    }

    // TODO : LeftSlide obj가 active일때, back버튼 누르면 LeftSlide obj 끄기
    void Update()
    {

    }

    public void basicScrollSetActive()
    {
        if (basicScroll.activeSelf == true)
            basicScroll.SetActive(false);
        else
            basicScroll.SetActive(true);
    }

    public void userScrollSetActive()
    {
        if (userScroll.activeSelf == true)
            userScroll.SetActive(false);
        else
            userScroll.SetActive(true);
    }

    // 화면전화 효과같은거 줘야할 것 같지만, 일단 생략
    public void gotoScheduler()
    {
        GM.myRoom.SetActive(false);
        GM.leftSlide.SetActive(false);
        GM.calendar.SetActive(true);
    }

}
