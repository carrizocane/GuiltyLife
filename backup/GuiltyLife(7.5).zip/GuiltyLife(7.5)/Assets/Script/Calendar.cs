﻿using System.Collections;
using UnityEngine;
using System.Globalization;
using System;

public class Calendar : MonoBehaviour {

    public UILabel date;
    public GameObject calendar;

    void OnEnable() {

        date.text = GM.currentDate.Year.ToString() +"년 "+ GM.currentDate.Month.ToString()+"월";
        //updateCalendar();
        
    }
    
    void updateCalendar() {//얘가 렉 쩔어.. 얘가 달력에 날짜 넣어주는 애임ㅇㅇ

        int i = 1;
        DateTime date = new DateTime(GM.currentDate.Year, GM.currentDate.Month, 1);
        GameObject week = calendar.transform.Find("week (1)").gameObject;
        UILabel dayNum;

        while (GM.currentDate.Month==date.Month) {

            switch (date.DayOfWeek) {

                case DayOfWeek.Sunday:
                    dayNum = (UILabel)week.transform.Find("day (1)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Monday:
                    dayNum = (UILabel)week.transform.Find("day (2)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Tuesday:
                    dayNum = (UILabel)week.transform.Find("day (3)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Wednesday:
                    dayNum = (UILabel)week.transform.Find("day (4)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Thursday:
                    dayNum = (UILabel)week.transform.Find("day (5)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Friday:
                    dayNum = (UILabel)week.transform.Find("day (6)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    break;
                case DayOfWeek.Saturday:
                    dayNum = (UILabel)week.transform.Find("day (7)").gameObject.transform.Find("Label").GetComponent("UILabel");
                    dayNum.text = date.Day.ToString();
                    i++;
                    week = calendar.transform.Find("week ("+i+")").gameObject;
                    break;
            }
            date.AddDays(1);
        }
    }

    public void gotoCalendarList()
    {
        GM.calendar.SetActive(false);
        GM.calendarList.SetActive(true);
    }

    public void gotoMyRoom() {
        GM.calendar.SetActive(false);
        GM.myRoom.SetActive(true);
        GM.getInstance().slideButton.SetActive(true);       //myRoom 켤 때는 얘도 켜야해염
    }

    public void preMonthButton()
    {
        GM.currentDate = GM.currentDate.AddMonths(-1);
        date.text = GM.currentDate.Year.ToString() + "년 " + GM.currentDate.Month.ToString() + "월";
    }

    public void nextMonthButton()
    {
        GM.currentDate = GM.currentDate.AddMonths(1);
        date.text = GM.currentDate.Year.ToString() + "년 " + GM.currentDate.Month.ToString() + "월";
    }

    public static void touch(GameObject day) {
        UILabel dayNum = (UILabel)day.transform.Find("Label").GetComponent("UILabel");
        GM.currentDate = new DateTime(GM.currentDate.Year, GM.currentDate.Month, Convert.ToInt32(dayNum.text));
        //라벨값 받아와서 현재 날짜 바꿔줌
    }

}
