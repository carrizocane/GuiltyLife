﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddTodo : MonoBehaviour
{
    public UIGrid grid;
    public GameObject s;

    public void addTodo()
    {
        GameObject newWork = Instantiate(s) as GameObject;
        newWork.transform.SetParent(grid.transform);
        newWork.transform.localScale = new Vector3(1, 1, 1);
        grid.Reposition();


        GM.addTodo.SetActive(false);
        GM.calendarList.SetActive(true);
    }
    public void cancel()
    {
        GM.addTodo.SetActive(false);
        GM.calendarList.SetActive(true);
    }

}
