﻿using System.Collections;
using UnityEngine;

public class Calendar : MonoBehaviour {

    public void gotoCalendarList()
    {
        GM.calendar.SetActive(false);
        GM.calendarList.SetActive(true);
    }

    public void gotoMyRoom() {
        GM.calendar.SetActive(false);
        GM.myRoom.SetActive(true);
    }
}
