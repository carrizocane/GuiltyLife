﻿using UnityEngine;
using System.Collections;

public class GM : MonoBehaviour
{

    /// UI Menu & Slide & Buttons
    public static GM gm;        // singleton
    public static GameObject leftSlide;
    public static GameObject myRoom;
    public static GameObject calendar;
    public static GameObject calendarList;      //날짜 선택 시 나오는 목록 object
    public static GameObject addWork;
    public static GameObject deleteWork;

    public GameObject slideButton;

    // Event Console
    public GameObject eventConsole;
    public UILabel eventName;
    public UILabel eventDetails;
    public UILabel eventMoneyCost;
    int basicEventCount = 0;
//    int conditionEventCount = 0;      일단 조건부 이벤트는 1개만 해보자
    const int basicEventNumber = 3;


    //DB & Data set
    public static LoadSaveManager loadSaveManager;
    public static UserData userData;
    public static Character characterData;

    // get GM instance
    public static GM getInstance()
    {
        return gm;
    }

    /// Awake : called before Start()
    /// 주의사항! object들이 켜져있어야 static 변수 초기화 가능!!
    void Awake()
    {
        // static 변수 초기화
        leftSlide = GameObject.FindGameObjectWithTag("LeftSlide");
        myRoom = GameObject.FindGameObjectWithTag("MyRoom");
        calendar = GameObject.FindGameObjectWithTag("Calendar");
        calendarList = GameObject.FindGameObjectWithTag("CalendarList");
        addWork = GameObject.FindGameObjectWithTag("AddWork");
        deleteWork = GameObject.FindGameObjectWithTag("DeleteWork");

        userData = new UserData();
        characterData = new Character();
        loadSaveManager = this.GetComponent<LoadSaveManager>();
    }

    /// Initialization
    void Start()
    {
        gm = this;
        //static 변수 초기화 이후, 쓰지 않는 UI 꺼줌
        addWork.SetActive(false);
        leftSlide.SetActive(false);
        calendar.SetActive(false);
        calendarList.SetActive(false);
        addWork.SetActive(false);
        deleteWork.SetActive(false);

        checkToday(Calendar.currentDateString);
    }

    /// Called once per frame
    void Update()
    {

    }

    /* 
     * Left Slide On & Off
     * TODO : 슬라이드 버튼 on/off -> LeftSlide 객체 on/off -> 애니메이션 및 MyRoom F.O. & F.I
     */
    public void LeftSlideOn()
    {
        Debug.Log("LeftSlide on");

        slideButton.SetActive(false);
        leftSlide.SetActive(true);

        // move left slide
        TweenPosition tw = leftSlide.AddComponent<TweenPosition>();
        tw.from.x = -640.0f;
        tw.to.x = -90.0f;
        tw.duration = 0.4f;
        tw.style = UITweener.Style.Once;
        tw.PlayForward();
    }

    public void LeftSlideOff()
    {
        Debug.Log("Left Slide Off");

        // move left slide
        TweenPosition tw = leftSlide.AddComponent<TweenPosition>();
        tw.from.x = -90.0f;
        tw.to.x = -640.0f;
        tw.duration = 0.4f;
        tw.style = UITweener.Style.Once;
        tw.onFinished.Add(new EventDelegate(this, "OnTweenFinished"));
        tw.PlayForward();
    }

    // off 트윈 종료 시 실행
    public void OnTweenFinished(UITweener tweener)
    {
        slideButton.SetActive(true);
        leftSlide.SetActive(false);
    }


    /// 오늘 첫 실행 시 함수
    /// ㄴ IEnumerator, Event Deligate 등 엿같은 코딩 출몰 예정!!
    /// ㄴ 코드가 좀 더러워지겠지만, 웬만하면 쟤네 안쓸련다! 어렵고 귀찮아!
    /// 
    /// 오늘의 isEventOccured 체크(LoadSaveManager에서 DB연동 함수 만들 것)
    /// -> 하루가 지났으니까, 기본적으로 빠져나가는 돈을 빼낸다 (월세)
    /// -> 이벤트 발생 요건 체크 (GM에서. 함수 델리게이트 쓰면 더 편함. 함수 +=해서 여러 이벤트 동적으로 처리 가능)
    /// -> 안좋은 아이들 이벤트 함수 실행
    /// -> 화면에 UI 출력 / 기본 + 조건 이벤트 담을 UI 추가 필요,터치 시 다음으로 넘어가는 코드 구현 [UI로 이벤트 보여주는 걸 IEnumerator 처리해야할듯]
    /// -> 게임머니 감소 후, 파산조건 체크
    /// -> 파산 시, 엔딩, 게임 초기화, 새 아이 입양 / 아니면 skip
    /// isEventOccured = true   (LSM에서 DB연동 함수 제작)
    /// 


    // 오늘 첫 접속 시 실행해야할 것을 총집합한 함수
    // 위에 적은 처리들을 모두 진행
    public void checkToday(string todayDate)
    {
        Debug.Log("[ check today called ]");
        if (loadSaveManager.isEventOccured(todayDate))      //true이면, 오늘 이미 이벤트를 봤음
            return;

        //basic event 실행, 이벤트 콘솔 onclick에서 그 다음 이벤트 UI까지 모두 처리
        basicDailyEvent("신개념 원룸! 월세가 아닌 일세를 내야합니다! 매일매일 지출하는 기쁨!", 2000);


        // event console이 off될 때 다음 함수 실행
        // IEnumerator 사용 귀찮아서 함수 쪼갬
    }
    public void checkToday2(string todayDate)
    {
        eventConsole.SetActive(false);
        //파산 조건 체크

        // 파산하면, 게임 오버(함수 따로 만들 것)
        // 파산 아니면 걍 패스

        loadSaveManager.setScheduleEventOccured(todayDate);     //이벤트 처리 완료
        loadSaveManager.saveUserData();       //변경된 돈 저장
        Debug.Log("[ Check today end ]");
    }

    // userData 정보(status) + 일정 수행 정도를 가지고 계산
    public void calculateStatus()
    {
        // 계산하고, conditional event 어떻게 이어줄지 생각하고 짜자.
    }

    // 기본적으로 발생하는 이벤트 처리
    // ex ) 일세(월세 아님)를 낸다, 식비 차감 등등
    // Params : 이벤트 정보, 게임머니 가격
    public void basicDailyEvent(string eventDetail, int eventMoney)
    {
        eventConsole.SetActive(true);
        eventName.text = "기본 이벤트 발생";
        eventDetails.text = eventDetail;
        eventMoneyCost.text = eventMoney.ToString();
        ++basicEventCount;
        userData.setGameMoney(userData.getGameMoney() - eventMoney);        //돈 감소
        myRoom.GetComponent<MyRoom>().UpdateStatusLabels();                 //UI 스탯, 돈 업데이트
    }

    // 이벤트 콘솔 터치 시 호출하는 함수
    // 여기서 다음 basic, conditional event 처리
    public void onEventConsoleTouched()
    {
        if(basicEventCount >= basicEventNumber)         //basic부터 모두 봤는지 검사
        {
            // 조건 이벤트 실행
            Debug.Log("[ Conditional Event ]");


            // 짜야함


            // 다 실행하고 나면
            checkToday2(Calendar.currentDateString);
        }
        //basic 이벤트 실행
        else
        {
            Debug.Log("[ Basic Event ]");
            switch (basicEventCount)        // 0번째는 여기서 실행하지 않음
            {
                case 1:
                    // parameter 텍스트를 랜덤하게 뽑아서 아무거나 넣는 게 더 재밌을 듯
                    basicDailyEvent("갑자기 내가 빙수가 먹고싶습니다. 빙수를 사줬습니다.", 1500);
                    break;
                case 2:
                     basicDailyEvent("음. 쓸 말이 없다. 300원 삥뜯겼습니다.", 300);
                    break;
                default:
                    Debug.Log("basic event count 에러");
                    break;
            }
        }
    }

    // conditional 이벤트 발생 여부 계산
    public void calculateConditionalEvent()
    {

    }


}