﻿using System.Collections;
using UnityEngine;
using System.Globalization;
using System;
using System.Collections.Generic;

public class Calendar : MonoBehaviour
{

    public UILabel date;
    public GameObject calendar;

    public static DateTime currentDate;
    public static DateTime tempDate;    // update Calendar에서 쓰는 Date 변수
    public static string currentDateString;

    void Awake()
    {
        currentDate = DateTime.Now;      // 이 인스턴스 생길 때 딱 한번 실행이니까 여기다 씀
        tempDate = currentDate;

        if (currentDate.Month >= 10 && currentDate.Day >= 10)
        {
            currentDateString = currentDate.Year + "-" + currentDate.Month + "-" + currentDate.Day;
        }
        else if (currentDate.Month >= 10)
        {
            currentDateString = currentDate.Year + "-" + currentDate.Month + "-0" + currentDate.Day;
        }
        else if (currentDate.Day >= 10)
        {
            currentDateString = currentDate.Year + "-0" + currentDate.Month + "-" + currentDate.Day;
        }
        else
        {
            currentDateString = currentDate.Year + "-0" + currentDate.Month + "-0" + currentDate.Day;
        }
    }

    void OnEnable()
    {
        date.text = tempDate.Year.ToString() + "년 " + tempDate.Month.ToString() + "월";
        updateCalendar();
    }

    void updateCalendar()
    {
        int i = 1;
        DateTime extraDate = new DateTime(tempDate.Year,  tempDate.Month, 1);
        GameObject week;
        UILabel dayNum;

        for (int j = 1; j <= 6; j++) {
            week = calendar.transform.Find("week ("+j+")").gameObject;
            for (int k = 1; k <= 7; k++)
            {
                dayNum = (UILabel)week.transform.Find("day ("+k+")").gameObject.transform.Find("Label").GetComponent("UILabel");
                dayNum.text = null;
            }
        }

        week = calendar.transform.Find("week (1)").gameObject;
        while (tempDate.Month == extraDate.Month)
        {
            switch (extraDate.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (1)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Monday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (2)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Tuesday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (3)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Wednesday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (4)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Thursday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (5)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Friday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (6)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        break;
                    }
                case DayOfWeek.Saturday:
                    {
                        dayNum = (UILabel)week.transform.Find("day (7)").gameObject.transform.Find("Label").GetComponent("UILabel");
                        dayNum.text = extraDate.Day.ToString();
                        i++;
                        week = calendar.transform.Find("week (" + i + ")").gameObject;
                        break;
                    }
            }
            extraDate = extraDate.AddDays(1);
        }
    }

    public void gotoCalendarList()
    {
        GM.calendar.SetActive(false);
        GM.calendarList.SetActive(true);
    }

    public void gotoMyRoom()
    {
        GM.calendar.SetActive(false);
        GM.myRoom.SetActive(true);
        GM.getInstance().slideButton.SetActive(true);       //myRoom 켤 때는 얘도 켜야해염
    }

    public void preMonthButton()
    {
        tempDate =  tempDate.AddMonths(-1);
        date.text =  tempDate.Year.ToString() + "년 " +  tempDate.Month.ToString() + "월";
        updateCalendar();
    }

    public void nextMonthButton()
    {
        tempDate =  tempDate.AddMonths(1);
        date.text =  tempDate.Year.ToString() + "년 " +  tempDate.Month.ToString() + "월";
        updateCalendar();
    }

  
}