﻿using UnityEngine;
using System.Collections;

public class LeftSlide : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// TODO : LeftSlide obj가 active일때, back버튼 누르면 LeftSlide obj 끄기
	void Update () {
	    
	}

    // 화면전화 효과같은거 줘야할 것 같지만, 일단 생략
    public void gotoScheduler()
    {
        GM.myRoom.SetActive(false);
        GM.leftSlide.SetActive(false);
        GM.calendar.SetActive(true);
    }

}
