﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddWork: MonoBehaviour
{
    
    public void addWork()
    {
        Schedule newWork = new Schedule("잠자기","USER","2017-07-10",false,false,1);
        GM.loadSaveManager.insertSchedule(newWork);

        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
        //여기서 원래 캘린더 false랑 true하는거 아닌데 얘네 왠지 오류나서 걍 false랑 true해둠..
        //궁금하면 두줄을 주석처리 해봐여 25줄과 19번째줄
    }
    public void cancel()
    {
        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }

}
