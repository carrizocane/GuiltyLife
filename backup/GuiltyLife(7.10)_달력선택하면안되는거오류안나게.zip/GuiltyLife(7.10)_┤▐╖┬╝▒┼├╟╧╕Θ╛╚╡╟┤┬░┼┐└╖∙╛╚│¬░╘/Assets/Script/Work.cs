﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Work : MonoBehaviour
{
    bool bIsPress = false;
    float fAccumTirme = 0f;
    int i = 0;

    public static int deleteNum = 0;

    void Update()
    {
        if (bIsPress)
        {
            fAccumTirme += Time.deltaTime;
            Debug.Log(fAccumTirme);
            if (fAccumTirme >= 3f)
            {
                if ((this.name[6]-48) <= GM.loadSaveManager.getBasicSchedules().Count)//6이 숫자있는애임
                {
                    Debug.Log("ㄴㄴ해");
                }
                else
                {
                    Debug.Log(GM.loadSaveManager.getBasicSchedules().Count);
                
                    deleteNum = this.name[6]-GM.loadSaveManager.getBasicSchedules().Count-48-1;//-1하는 이유는 배열은 0부터 시작

                    Debug.Log(deleteNum);

                    GM.calendarList.SetActive(false);
                    GM.deleteWork.SetActive(true);
                    Debug.Log("롱터치" + i);
                    i++;
                }
                fAccumTirme = 0f;
            }
        }
    }

    void OnPress()
    {
        bIsPress = true;
    }

    void OnRelease()
    {
        bIsPress = false;
    }
}
