﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteWork : MonoBehaviour {

    public void deleteWork() {

        Schedule deleteSchedule = GM.loadSaveManager.getSchedulesWithDate(Calendar.currentDateString)[Work.deleteNum];

        GM.loadSaveManager.deleteSchedule(deleteSchedule);
        
        GM.deleteWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }
    public void cancel()
    {
        GM.deleteWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }
}
