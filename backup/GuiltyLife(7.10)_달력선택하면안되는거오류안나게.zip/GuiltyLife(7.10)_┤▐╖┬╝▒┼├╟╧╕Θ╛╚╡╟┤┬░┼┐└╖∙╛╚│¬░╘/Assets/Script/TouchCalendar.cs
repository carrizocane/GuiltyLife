﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchCalendar : MonoBehaviour
{
    public UIGrid grid;
    public UILabel date;
    public UIScrollView touchScroll;
    public bool enableFlag;

    void Awake()
    {
        enableFlag = true;
    }

    void OnEnable()
    {
        date.text = Calendar.tempDate.Year.ToString() + "년 " + Calendar.tempDate.Month.ToString() + "월 " + Calendar.tempDate.Day.ToString() + "일";
        if (enableFlag)
        {
            enableFlag = false;
            return;
        }
        destroyWork();
        setWork();
    }

    public void destroyWork()
    {
        int destroyCount = grid.transform.childCount;
        if (destroyCount != 0)
        {
            for (int i = 0; i < destroyCount; i++)
            {
                GameObject destroyObj = grid.transform.Find("work (" + (i + 1) + ")").gameObject;
                Destroy(destroyObj);
            }
        }
    }

    public void setWork()
    {
        GameObject prefab = Resources.Load("Prefabs/work") as GameObject;
        // Resources/Prefabs/work.prefab 로드
        GameObject work;
        UILabel label;

        UIDragScrollView setScrollView;
        List<Schedule> basicScheduleList = GM.loadSaveManager.getBasicSchedules();
        List<Schedule> userScheduleList = GM.loadSaveManager.getSchedulesWithDate(Calendar.currentDateString);

        for (int i = 0; i < basicScheduleList.Count; i++)
        {
            work = MonoBehaviour.Instantiate(prefab) as GameObject;
            work.name = "work (" + (1 + i) + ")"; // name을 변경

            label = (UILabel)work.transform.Find("Label").GetComponent("UILabel"); //라벨 받아와서
            label.text = basicScheduleList[i].getContent(); //내용 넣기

            if (basicScheduleList[i].getDone())
            { //이미 한 일정이면
                work.transform.Find("check").gameObject.SetActive(true); //체크하기
            }
            work.transform.SetParent(grid.transform);
            work.transform.localScale = new Vector3(1, 1, 1);

            setScrollView = (UIDragScrollView)work.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)touchScroll.GetComponent("UIScrollView");
        }
        for (int i = 0; i < userScheduleList.Count; i++)
        {
            work = MonoBehaviour.Instantiate(prefab) as GameObject;
            work.name = "work (" + (basicScheduleList.Count+1 + i) + ")"; // name을 변경

            label = (UILabel)work.transform.Find("Label").GetComponent("UILabel"); //라벨 받아와서
            label.text = userScheduleList[i].getContent(); //내용 넣기

            if (userScheduleList[i].getDone())
            { //이미 한 일정이면
                work.transform.Find("check").gameObject.SetActive(true); //체크하기
            }
            work.transform.SetParent(grid.transform);
            work.transform.localScale = new Vector3(1, 1, 1);

            setScrollView = (UIDragScrollView)work.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)touchScroll.GetComponent("UIScrollView");
        }

        grid.Reposition();
        

    }

    public void gotoAddWork()
    {
        GM.calendarList.SetActive(false);
        //원래 위에 9번줄 false하면 안되는뎅..근데 false해도 안없어지고
        //false를 안하면 쟤의 depth가 낮은데도 불구하고 위로 올라옴..;;
        GM.addWork.SetActive(true);
    }

    public void gotoCalendar()
    {
        GM.calendarList.SetActive(false);
        GM.calendar.SetActive(true);
    }

    public void preDayButton()
    {
        Calendar.tempDate = Calendar.tempDate.AddDays(-1);
        date.text = Calendar.tempDate.Year.ToString() + "년 " + Calendar.tempDate.Month.ToString() + "월 " + Calendar.tempDate.Day.ToString() + "일";
    }

    public void nextDayButton()
    {
        Calendar.tempDate = Calendar.tempDate.AddDays(1);
        date.text = Calendar.tempDate.Year.ToString() + "년 " + Calendar.tempDate.Month.ToString() + "월 " + Calendar.tempDate.Day.ToString() + "일";
    }
}
