﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LeftSlide : MonoBehaviour
{

    public UIGrid basicGrid;
    public UIGrid userGrid;
    public GameObject basicScroll;
    public GameObject userScroll;
    public GameObject date;
    public bool enableFlag;

    void Awake()
    {
        enableFlag = true;
    }
    void Start()
    {
        UILabel year = (UILabel)date.transform.Find("year").GetComponent("UILabel");
        UILabel day = (UILabel)date.transform.Find("day").GetComponent("UILabel");
        year.text = Calendar.currentDate.Year.ToString() + "년";
        day.text = Calendar.currentDate.Month.ToString() + "월 " + Calendar.currentDate.Day.ToString() + "일";
    }
    
    void OnEnable(){
        if (enableFlag)
        {
            enableFlag = false;
            return;
        }
        setListItem();       
    }

    public void setListItem() {

        GameObject prefab = Resources.Load("Prefabs/listItem") as GameObject;
        // Resources/Prefabs/listItem.prefab 로드
        GameObject listItem;
        UILabel label;
        UIDragScrollView setScrollView;

        List<Schedule> userScheduleList = GM.loadSaveManager.getSchedulesWithDate(Calendar.currentDateString);
        List<Schedule> basicScheduleList = GM.loadSaveManager.getBasicSchedules();
        //데이터 받아옴

        for (int i = 0; i < basicScheduleList.Count; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "basicItemList"; // name을 변경

            label = (UILabel)listItem.transform.Find("Label").GetComponent("UILabel"); //라벨 찾아서
            label.text = basicScheduleList[i].getContent(); //내용넣기

            if (basicScheduleList[i].getDone()) //만약 이미 한 상태면
            {
                listItem.transform.Find("checkIcon").gameObject.SetActive(true); //체크하기
            }

            listItem.transform.SetParent(basicGrid.transform);

            listItem.transform.localScale = new Vector3(1, 1, 1);
            setScrollView = (UIDragScrollView)listItem.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)basicScroll.GetComponent("UIScrollView");
        }
        basicGrid.Reposition();

        for (int i = 0; i < userScheduleList.Count; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "userItemList"; // name을 변경

            label = (UILabel)listItem.transform.Find("Label").GetComponent("UILabel"); //라벨 찾아서
            label.text = userScheduleList[i].getContent(); //내용넣기

            if (userScheduleList[i].getDone()) //만약 이미 한 상태면
            {
                listItem.transform.Find("checkIcon").gameObject.SetActive(true); //체크하기
            }

            listItem.transform.SetParent(userGrid.transform);
            listItem.transform.localScale = new Vector3(1, 1, 1);
            setScrollView = (UIDragScrollView)listItem.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)userScroll.GetComponent("UIScrollView");
        }
        userGrid.Reposition();
    }

    void Update()
    {
        //  LeftSlide obj가 active일때, back버튼 누르면 LeftSlide obj 끄기
        if (Input.GetKeyDown(KeyCode.Escape) && GM.leftSlide.activeSelf)
        {
            GM.getInstance().LeftSlideOff();
        }
    }

    public void basicScrollSetActive()
    {
        if (basicScroll.activeSelf == true)
            basicScroll.SetActive(false);
        else
            basicScroll.SetActive(true);
    }

    public void userScrollSetActive()
    {
        if (userScroll.activeSelf == true)
            userScroll.SetActive(false);
        else
            userScroll.SetActive(true);
    }

    // 화면전화 효과같은거 줘야할 것 같지만, 일단 생략
    public void gotoScheduler()
    {
        GM.myRoom.SetActive(false);
        GM.leftSlide.SetActive(false);
        GM.calendar.SetActive(true);
    }

}
