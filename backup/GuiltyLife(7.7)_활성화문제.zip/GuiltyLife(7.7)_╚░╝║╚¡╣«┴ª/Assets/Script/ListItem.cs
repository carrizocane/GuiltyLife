﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListItem : MonoBehaviour {

    // 수행하지 않은 일정 터치 -> 일정을 한 것으로 바꿈 (체크 아이콘 on)
    // 이미 수행한 일정 터치 -> 아무 일 일어나지 않음
    void OnClick() {
        itemOnClick();
    }

    public void itemOnClick()
    {
        Debug.Log("[ item on click called ]");

        List<Schedule> basicScheduleList = GM.loadSaveManager.getBasicSchedules();
        List<Schedule> userScheduleList = GM.loadSaveManager.getSchedulesWithDate(Calendar.currentDateString);
        
        int index = 0;
        UILabel label =(UILabel)this.transform.Find("Label").GetComponent("UILabel");

        if (this.transform.Find("checkIcon").gameObject.activeSelf)
            return;
        else
        {
           if ("BasicGrid" == this.transform.parent.name)
            {
                for (; index < basicScheduleList.Count; index++)
                {
                    if ( label.text.Equals(basicScheduleList[index].getContent()))
                    {
                        break;
                    }
                }
                if (index == basicScheduleList.Count)
                {
                    return;
                }
                GM.userData.setGameMoney(GM.userData.getGameMoney() + basicScheduleList[index].getCost());
                basicScheduleList[index].setDone(true);
            }
            else if ("UserGrid" == this.transform.parent.name)
            {
                for (; index < userScheduleList.Count; index++)
                {
                    if (label.text.Equals(userScheduleList[index].getContent()))
                        {
                        break;
                    }
                }
                if (index == userScheduleList.Count)
                {
                    return;
                }
                GM.userData.setGameMoney(GM.userData.getGameMoney() + userScheduleList[index].getCost());
                userScheduleList[index].setDone(true);
            }
            this.transform.Find("checkIcon").gameObject.SetActive(true);
            GM.myRoom.GetComponent<MyRoom>().UpdateStatusLabels();
        }

    }
}
