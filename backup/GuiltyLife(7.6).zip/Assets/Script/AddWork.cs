﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddWork: MonoBehaviour
{
    public UIGrid grid;

    public void addWork()
    {
        GameObject prefab = Resources.Load ("Prefabs/work") as GameObject;
        // Resources/Prefabs/work.prefab 로드
        GameObject newWork = MonoBehaviour.Instantiate (prefab) as GameObject;
        // 실제 인스턴스 생성
        newWork.name = "work"; // name을 변경
        newWork.transform.SetParent(grid.transform);
        newWork.transform.localScale = new Vector3(1, 1, 1);
        grid.Reposition();

        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
        //여기서 원래 캘린더 false랑 true하는거 아닌데 얘네 왠지 오류나서 걍 false랑 true해둠..
        //궁금하면 두줄을 주석처리 해봐여 25줄과 19번째줄
    }
    public void cancel()
    {
        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }

}
