﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchCalendar : MonoBehaviour {

    public UIGrid grid;
    public UILabel date;

    void OnEnable() {

        date.text = Calendar.tempDate.Year.ToString() + "년 " + Calendar.tempDate.Month.ToString() + "월 " + Calendar.tempDate.Day.ToString() + "일";

    }
    
    void Start() {
        
        GameObject prefab = Resources.Load("Prefabs/work") as GameObject;
        // Resources/Prefabs/work.prefab 로드
        GameObject work;
        UILabel label;

        List <Schedule> scheduleList = GM.loadSaveManager.ScheduleDbParsing();

        for (int i = 0; i < scheduleList.Count; i++)
        {
            work = MonoBehaviour.Instantiate(prefab) as GameObject;
            work.name = "work"; // name을 변경

            label = (UILabel)work.transform.Find("Label").GetComponent("UILabel"); //라벨 받아와서
            label.text = scheduleList[i].getContent(); //내용 넣기

            if (scheduleList[i].getDone()) { //이미 한 일정이면
                work.transform.Find("check").gameObject.SetActive(true); //체크하기
            }
            work.transform.SetParent(grid.transform);
            work.transform.localScale = new Vector3(1, 1, 1);
        }
        grid.Reposition();
 
    }

    public void gotoAddWork()
    {
        GM.calendarList.SetActive(false);
        //원래 위에 9번줄 false하면 안되는뎅..근데 false해도 안없어지고
        //false를 안하면 쟤의 depth가 낮은데도 불구하고 위로 올라옴..;;
        GM.addWork.SetActive(true);
    }

    public void gotoCalendar() {
        GM.calendarList.SetActive(false);
        GM.calendar.SetActive(true);
    }

    public void preDayButton() {
        Calendar.tempDate =  Calendar.tempDate.AddDays(-1);
        date.text =  Calendar.tempDate.Year.ToString() + "년 " +  Calendar.tempDate.Month.ToString() + "월 " +  Calendar.tempDate.Day.ToString() + "일";
    }

    public void nextDayButton() {
        Calendar.tempDate =  Calendar.tempDate.AddDays(1);
        date.text =  Calendar.tempDate.Year.ToString() + "년 " +  Calendar.tempDate.Month.ToString() + "월 " +  Calendar.tempDate.Day.ToString() + "일";
    }
}
