﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LeftSlide : MonoBehaviour
{

    public UIGrid basicGrid;
    public UIGrid userGrid;
    public GameObject basicScroll;
    public GameObject userScroll;
    public GameObject date;

    // 쓸지 안쓸지 모르는데 언젠가를 위해 그냥 만듬 ㅋㅋㅋ
    public List<GameObject> basicListItems;      //basic List Item 저장 배열
    public List<GameObject> userListItems;      //basic List Item 저장 배열

    void Start()
    {
        basicListItems.Clear();

        UILabel year = (UILabel)date.transform.Find("year").GetComponent("UILabel");
        UILabel day = (UILabel)date.transform.Find("day").GetComponent("UILabel");
        year.text =  Calendar.currentDate.Year.ToString() + "년";
        day.text =  Calendar.currentDate.Month.ToString() + "월 " +  Calendar.currentDate.Day.ToString() + "일";

        GameObject prefab = Resources.Load("Prefabs/listItem") as GameObject;
        // Resources/Prefabs/listItem.prefab 로드
        GameObject listItem;
        UILabel label;
        UIDragScrollView setScrollView;
        List<Schedule> scheduleList = GM.loadSaveManager.ScheduleDbParsing();
        //데이터 받아옴
        
        for (int i = 0; i < scheduleList.Count; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "basicItemList"; // name을 변경

            label = (UILabel)listItem.transform.Find("Label").GetComponent("UILabel"); //라벨 찾아서
            label.text = scheduleList[i].getContent(); //내용넣기

            if (scheduleList[i].getDone()) //만약 이미 한 상태면
            {
                listItem.transform.Find("checkIcon").gameObject.SetActive(true); //체크하기
            }

            listItem.transform.SetParent(basicGrid.transform);
            listItem.transform.localScale = new Vector3(1, 1, 1);
            setScrollView = (UIDragScrollView)listItem.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)basicScroll.GetComponent("UIScrollView");
            basicListItems.Add(listItem);           //리스트에 추가
        }
        basicGrid.Reposition();
        
        for (int i = 0; i < 2; i++)
        {
            listItem = Instantiate(prefab) as GameObject;
            listItem.name = "userItemList"; // name을 변경

            listItem.transform.SetParent(userGrid.transform);
            listItem.transform.localScale = new Vector3(1, 1, 1);
            setScrollView = (UIDragScrollView)listItem.GetComponent("UIDragScrollView");
            setScrollView.scrollView = (UIScrollView)userScroll.GetComponent("UIScrollView");
            userListItems.Add(listItem);            //리스트에 추가
        }
        userGrid.Reposition();

    }

    void Update()
    {
    //  LeftSlide obj가 active일때, back버튼 누르면 LeftSlide obj 끄기
        if (Input.GetKeyDown(KeyCode.Escape) && GM.leftSlide.activeSelf)
        {
            GM.getInstance().LeftSlideOff();
        }
    }

    public void basicScrollSetActive()
    {
        if (basicScroll.activeSelf == true)
            basicScroll.SetActive(false);
        else
            basicScroll.SetActive(true);
    }

    public void userScrollSetActive()
    {
        if (userScroll.activeSelf == true)
            userScroll.SetActive(false);
        else
            userScroll.SetActive(true);
    }

    // 화면전화 효과같은거 줘야할 것 같지만, 일단 생략
    public void gotoScheduler()
    {
        GM.myRoom.SetActive(false);
        GM.leftSlide.SetActive(false);
        GM.calendar.SetActive(true);
    }

    // 수행하지 않은 일정 터치 -> 일정을 한 것으로 바꿈 (체크 아이콘 on)
    // 이미 수행한 일정 터치 -> 아무 일 일어나지 않음
    public void itemOnClick(GameObject i) {
        Debug.Log("[ item on click called ]");
        if (i.transform.Find("checkIcon").gameObject.activeSelf)
            return;
        else
        {
            i.transform.Find("checkIcon").gameObject.SetActive(true);
 //            GM.userData.setGameMoney(GM.userData.getGameMoney() + 얘가 가진 일정.getCost());
            GM.myRoom.GetComponent<MyRoom>().UpdateStatusLabels();
        }
    }

}
