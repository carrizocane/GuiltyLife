﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Schedule
{

    private string content = "";    // 일정
    private string type = "";       // USER or BASIC
    private string date = "YYYY-MM-DD";     //날짜        //아직 안쓰고 테스트할거라..ㅇㅇ
    private bool isEventOccured;    //이 날에 이벤트를 봤는지(당일 앱 처음 실행 시 발생함)
    private bool isDone;            //해당 일정이 수행되었는지

    //constructor
    public Schedule()
    {
        setContent("TODO");
        setType("USER");
        setDate("YYYY-MM-DD");
        setEventOccured(false);
        setDone(false);
    }

    public Schedule(string content, string type, string date, bool isEventOccured, bool isDone)
    {
        setContent(content);
        setType(type);
        setDate(date);
        setEventOccured(isEventOccured);
        setDone(isDone);
    }

    //setters & getters
    public void setContent(string content)
    {
        this.content = content;
    }

    public string getContent()
    {
        return content;
    }

    public void setType(string type)
    {
        if (type.Equals("USER") || type.Equals("BASIC"))
            this.type = type;
        else
            Debug.Log("setType() error : " + type);
    }

    public string getType()
    {
        return type;
    }

    public void setDate(string date)
    {
        this.date = date;
    }

    public string getDate()
    {
        return date;
    }

    public void setEventOccured(bool isEventOccured)
    {
        this.isEventOccured = isEventOccured;
    }

    public bool getEventOccured()
    {
        return isEventOccured;
    }

    //SQL 때문에 만듬
    public int getEventOccuredInt()
    {
        if (isEventOccured == false)
            return 0;
        else
            return 1;
    }

    public void setDone(bool isDone)
    {
        this.isDone = isDone;
    }

    public bool getDone()
    {
        return isDone;
    }

    public int getDoneInt()
    {
        if (isDone == false)
            return 0;
        else
            return 1;
    }

    //디버그용
    public string print()
    {
        return "" + this.getContent() + ", " + this.getType() + ", " + this.getDate() + ", " + this.getEventOccured() + ", " + this.getDone();
    }

}
