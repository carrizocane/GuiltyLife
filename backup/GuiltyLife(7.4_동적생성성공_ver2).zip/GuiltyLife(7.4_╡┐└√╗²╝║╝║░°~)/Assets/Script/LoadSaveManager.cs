﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.SqliteClient;
using System.IO;        //파일 parsing 위해서 필요
using System.Data;


/*
 * 이것도 GM에 static 변수로 되어있어서, 모든 스크립트에서 이거 사용 가능함
 * 
 * 
 * [ DB 간략 설명 ]
   
   SQLite 사용
   db 파일 이름은 "scheduler.sqlite"       //StreamingAssets 폴더에 있어
   테이블은 "schedule" 만 있는 상태          // 일정 담는 용도
   schedule 구성하는 필드는 현재 5개          // Schedule 클래스 파일 참고할 것
   
   scheduler db 파싱해서, Schedule 리스트에 일정 정보를 저장하는 것 까지 구현한 상태

   참고 :
   DB는 여러 테이블로 구성 / 한 테이블에는 여러 필드 존재 / 각 필드에는 타입이 주어짐
*/


public class LoadSaveManager : MonoBehaviour
{
    //db에 있는 모든 일정을 리턴
    // 사용할 때, List<Schedule> 변수 만들어서, 이 함수 대입하면 일정을 가져올 수 있지!
    public List<Schedule> ScheduleDbParsing()
    {
        Debug.Log("parsing...");

        List<Schedule> ScheduleList = new List<Schedule>();     // 일정 리스트

        string p = "scheduler.sqlite";          //db 파일 이름
        string filePath = Application.persistentDataPath + "/" + p;

        if (!File.Exists(filePath))
        {
            Debug.LogWarning("File \"" + filePath + "\"does not exist. Attempting to create from \"" + Application.dataPath + "!/assets/" + p);

            WWW loadDB = new WWW("jar:file://" + Application.dataPath + "!/assets/" + p);
            while (!loadDB.isDone) { }
            File.WriteAllBytes(filePath, loadDB.bytes);
        }
        string connectionString = "URI=file:" + filePath;
        ScheduleList.Clear();

        //using 써서, 비정상적 예외 발생해도 파일이 닫힘
        using (IDbConnection dbConnection = new SqliteConnection(connectionString))
        {
            dbConnection.Open();

            using (IDbCommand dbCmd = dbConnection.CreateCommand())  // sql 명령 가능 
            {
                //명령어 전달
                string sqlQuery = "SELECT * FROM schedule";     //'schedule'은 db에서 일정 저장하는 table
                dbCmd.CommandText = sqlQuery;

                using (IDataReader reader = dbCmd.ExecuteReader()) // schedule table의 정보들 읽어서 저장
                {
                    while (reader.Read())
                    {
                        //ScheduleList에 add
                        ScheduleList.Add(new Schedule(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetBoolean(3), reader.GetBoolean(4)));
                    }

                    // 값 제대로 들어갔나 확인할 때 쓰세염!
                    for (int i = 0; i < ScheduleList.Count; i++)
                    {  Debug.Log(i + "째 data : " + ScheduleList[i].print());  }

                    dbConnection.Close();
                    reader.Close();

                }   //end data reader
            }   //end db command
        }      //end db connection

        return ScheduleList;
    }   // db parsing 함수 끝

    void Start() {
        ScheduleDbParsing();
    }

}
