﻿using UnityEngine;
using System.Collections;

public class GM : MonoBehaviour {

    /// UI Menu & Slide & Buttons
    public static GM gm;        // singleton
    public static GameObject leftSlide;
    public static GameObject myRoom;
    public static GameObject calendar;
    public static GameObject calendarList;      //날짜 선택 시 나오는 목록 object
    public static GameObject addWork;

    public GameObject slideButton;

    //DB
    public static LoadSaveManager loadSaveManager;

    // get GM instance
    public static GM getInstance()
    {
        return gm;
    }

    /// Awake : called before Start()
    /// 주의사항! object들이 켜져있어야 static 변수 초기화 가능!!
    void Awake()
    {
        // static 변수 초기화
        leftSlide = GameObject.FindGameObjectWithTag("LeftSlide");
        myRoom = GameObject.FindGameObjectWithTag("MyRoom");
        calendar = GameObject.FindGameObjectWithTag("Calendar");
        calendarList = GameObject.FindGameObjectWithTag("CalendarList");
        addWork = GameObject.FindGameObjectWithTag("AddWork");
        loadSaveManager = this.GetComponent<LoadSaveManager>(); 
    }

	/// Initialization
	void Start () {
        gm = this;
        //static 변수 초기화 이후, 쓰지 않는 UI 꺼줌
        addWork.SetActive(false);
        leftSlide.SetActive(false);
        calendar.SetActive(false);
        calendarList.SetActive(false);
        addWork.SetActive(false);
    }

	/// Called once per frame
	void Update () {
	    
	}

    /* 
     * Left Slide On & Off
     * TODO : 슬라이드 버튼 on/off -> LeftSlide 객체 on/off -> 애니메이션 및 MyRoom F.O. & F.I
     */  
    public void LeftSlideOn()
    {
        Debug.Log("LeftSlide on");

        slideButton.SetActive(false);
        leftSlide.SetActive(true);

        // move left slide
        TweenPosition tw = leftSlide.AddComponent<TweenPosition>();
        tw.from.x = -640.0f;
        tw.to.x = -90.0f;
        tw.duration = 0.4f;
        tw.style = UITweener.Style.Once;
        tw.PlayForward();
    }

    public void LeftSlideOff()
    {
        Debug.Log("Left Slide Off");

        // move left slide
        TweenPosition tw = leftSlide.AddComponent<TweenPosition>();
        tw.from.x = -90.0f;
        tw.to.x = -640.0f;
        tw.duration = 0.4f;
        tw.style = UITweener.Style.Once;
        tw.onFinished.Add(new EventDelegate(this, "OnTweenFinished"));
        tw.PlayForward();        
    }

    // off 트윈 종료 시 실행
    public void OnTweenFinished(UITweener tweener)
    {
        slideButton.SetActive(true);
        leftSlide.SetActive(false);
    }
}
