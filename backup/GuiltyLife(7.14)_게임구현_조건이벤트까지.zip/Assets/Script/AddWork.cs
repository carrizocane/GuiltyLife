﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddWork: MonoBehaviour
{
    public GameObject inputContent;
    public string inputStr;
    public static UIInput input;
    public GameObject inputClaTitle;
    
    public void setContentInput() {//내용입력받음
        //여기서 내용글자갯수나 그런거 제한해줘야할듯
        input = inputContent.GetComponent<UIInput>();
        inputStr = input.label.text;
    }

    public void addWork()
    {
        Debug.Log("AddWork.cs의 addWork()");
        string tempDateString; //날 받아옴 string으로
        if (Calendar.tempDate.Month >= 10 && Calendar.tempDate.Day >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-" + Calendar.tempDate.Month + "-" + Calendar.tempDate.Day;
        }
        else if (Calendar.tempDate.Month >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-" + Calendar.tempDate.Month + "-0" + Calendar.tempDate.Day;
        }
        else if (Calendar.tempDate.Day >= 10)
        {
            tempDateString = Calendar.tempDate.Year + "-0" + Calendar.tempDate.Month + "-" + Calendar.tempDate.Day;
        }
        else
        {
            tempDateString = Calendar.tempDate.Year + "-0" + Calendar.tempDate.Month + "-0" + Calendar.tempDate.Day;
        }

        // 일정의 날짜가 오늘인 경우, isEventOccured=true로 해줘야함.
        // 안 그러면 이벤트 발생 초기화됨
        if (tempDateString.Equals(Calendar.currentDateString))
        {
            Schedule newWork = new Schedule(inputStr,"USER",tempDateString,true,false,inputClassfication.cla);
            GM.loadSaveManager.insertSchedule(newWork);
        }
        else
        {
            Schedule newWork = new Schedule(inputStr, "USER", tempDateString, false, false, inputClassfication.cla);
            GM.loadSaveManager.insertSchedule(newWork);
        }

       // input.label.text = ""; 이거 왜 오류지...?
        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }
    public void cancel()
    {
        GM.addWork.SetActive(false);
        GM.calendarList.SetActive(true);
    }

}
